/*
 * Copyright (c) 2022 Roelof Bart Toonen
 * License: MIT license (spdx.org MIT)
 *
 */

#ifndef DATALIMITS_H
#define DATALIMITS_H

#define MAX_COLS        300
#define MAX_COLNAME_SZ  100

#endif
